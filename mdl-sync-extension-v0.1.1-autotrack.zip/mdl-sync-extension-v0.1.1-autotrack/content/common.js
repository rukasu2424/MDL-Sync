// ============================================================
// LÓGICA COMUM — compartilhada por todos os sites.
// Cada arquivo de site só precisa definir SITE_PARSER e chamar
// MDLSyncCommon.init(SITE_PARSER) no final.
// ============================================================

const AUTO_SYNC_THRESHOLD = 0.8; // 80%

window.MDLSyncCommon = {
  init(SITE_PARSER) {
    this._attemptDetection(SITE_PARSER);
    this._watchUrlChanges(SITE_PARSER);
  },

  // Tenta detectar por alguns segundos, caso o site seja uma SPA
  // (Angular/React/Vue) que ainda não terminou de renderizar o título/
  // conteúdo quando o content script roda (ex: kisskh).
  _attemptDetection(SITE_PARSER) {
    const maxAttempts = 16; // ~8 segundos no total
    const intervalMs = 500;
    let attempts = 0;

    const tryDetect = async () => {
      attempts++;
      const episodeData = this._detectEpisode(SITE_PARSER);

      if (episodeData) {
        console.log("[MDL Sync] Episódio detectado:", episodeData);

        // Já foi sincronizado antes (manual ou automático)? Mostra o
        // botão já no estado "sincronizado" — assim ninguém (principalmente
        // quem não configurou a extensão) fica em dúvida se precisa clicar.
        const alreadySynced = await this._wasAlreadySynced(episodeData);
        this._createSyncBadge(episodeData, alreadySynced);

        chrome.storage.local.set({ lastDetected: episodeData });

        // Só liga o auto-sync por % assistido se esse título JÁ tiver um
        // mapeamento salvo (ou seja, alguém já resolveu manualmente pelo
        // menos uma vez qual é a entrada certa no MDL). Sem isso, o
        // auto-sync nunca abre busca sozinho no meio do episódio.
        if (!alreadySynced) {
          chrome.storage.local.get("mdlMap", ({ mdlMap }) => {
            if (mdlMap && mdlMap[episodeData.key]) {
              this._setupAutoTrack(episodeData);
            }
          });
        }

        return;
      }

      if (attempts < maxAttempts) {
        setTimeout(tryDetect, intervalMs);
      } else {
        console.log("[MDL Sync] Não foi possível detectar título/episódio nesta página (mesmo após aguardar).");
      }
    };

    tryDetect();
  },

  // Sites SPA podem trocar de episódio sem recarregar a página (ex: clicar
  // em "próximo"). Isso detecta a mudança de URL e roda a detecção de novo,
  // sem criar um novo monitor a cada vez (só um setInterval por página).
  _watchUrlChanges(SITE_PARSER) {
    if (this._watchingUrl) return;
    this._watchingUrl = true;

    let lastUrl = window.location.href;
    setInterval(() => {
      if (window.location.href !== lastUrl) {
        lastUrl = window.location.href;
        console.log("[MDL Sync] URL mudou, tentando detectar de novo...");
        this._attemptDetection(SITE_PARSER);
      }
    }, 1000);
  },

  // Chave usada pra guardar "esse episódio específico já foi sincronizado",
  // persistente entre reloads/sessões (diferente do "synced" em memória
  // usado só pra travar o listener do <video> na mesma carga de página).
  _syncedStorageKey(episodeData) {
    return `${episodeData.key}:${episodeData.episode}`;
  },

  _wasAlreadySynced(episodeData) {
    return new Promise((resolve) => {
      chrome.storage.local.get("syncedEpisodes", ({ syncedEpisodes }) => {
        const storageKey = this._syncedStorageKey(episodeData);
        resolve(Boolean(syncedEpisodes && syncedEpisodes[storageKey]));
      });
    });
  },

  _markAsSynced(episodeData) {
    chrome.storage.local.get("syncedEpisodes", ({ syncedEpisodes }) => {
      const map = syncedEpisodes || {};
      map[this._syncedStorageKey(episodeData)] = Date.now();
      chrome.storage.local.set({ syncedEpisodes: map });
    });
  },

  // Liga o auto-sync: acha o <video> da página e, ao passar de 80% do
  // episódio, dispara o sync automaticamente (sem precisar clicar no
  // botão). Só é chamado quando o mapeamento pro MDL já existe.
  _setupAutoTrack(episodeData) {
    let synced = false;
    let attempts = 0;
    const maxAttempts = 30; // ~30s esperando o player carregar o <video>

    // Invalida o listener anterior se um novo episódio foi detectado antes
    // dele terminar (evita continuar escutando o <video> do episódio errado
    // em players SPA que reaproveitam a mesma tag <video>).
    this._autoTrackGeneration = (this._autoTrackGeneration || 0) + 1;
    const myGeneration = this._autoTrackGeneration;

    const attach = () => {
      if (myGeneration !== this._autoTrackGeneration) return; // superado por episódio mais novo

      const video = document.querySelector("video");

      if (!video) {
        attempts++;
        if (attempts < maxAttempts) setTimeout(attach, 1000);
        return;
      }

      console.log(`[MDL Sync] Auto-sync ativo (dispara ao passar de ${AUTO_SYNC_THRESHOLD * 100}%).`);
      this._updateBadgeAutoLabel();

      video.addEventListener("timeupdate", () => {
        if (myGeneration !== this._autoTrackGeneration) return;
        if (synced) return;
        if (!video.duration || isNaN(video.duration)) return;

        const pct = video.currentTime / video.duration;
        if (pct >= AUTO_SYNC_THRESHOLD) {
          synced = true;
          console.log(`[MDL Sync] ${AUTO_SYNC_THRESHOLD * 100}% atingido — sincronizando automaticamente...`);
          chrome.runtime.sendMessage({ type: "SYNC_EPISODE", source: "auto", data: episodeData }, (response) => {
            if (response?.ok) {
              console.log("[MDL Sync] Auto-sync concluído.");
              this._markAsSynced(episodeData);
              this._setBadgeSyncedState("Sincronizado automaticamente ✓");
            } else {
              console.warn("[MDL Sync] Auto-sync falhou:", response?.error);
            }
          });
        }
      });
    };

    attach();
  },

  // Pequeno indicativo visual no badge de que o auto-sync está ativo
  // nesse episódio.
  _updateBadgeAutoLabel() {
    const badge = document.getElementById("mdl-sync-badge");
    if (!badge) return;
    if (badge.querySelector(".mdl-sync-auto-label")) return;

    const autoLabel = document.createElement("span");
    autoLabel.className = "mdl-sync-auto-label";
    autoLabel.textContent = `🔄 auto ${AUTO_SYNC_THRESHOLD * 100}%`;
    autoLabel.style.cssText = "font-size: 11px; color: #4da3ff; margin-left: 4px;";
    badge.appendChild(autoLabel);
  },

  // Deixa o botão do badge permanentemente no estado "sincronizado" —
  // fica assim mesmo depois de sair da tela cheia ou recarregar a página
  // (graças ao _wasAlreadySynced/_markAsSynced), então quem não sabe que
  // o auto-sync existe não fica em dúvida se precisa clicar de novo.
  _setBadgeSyncedState(text) {
    const badge = document.getElementById("mdl-sync-badge");
    if (!badge) return;
    const button = badge.querySelector("button");
    if (!button) return;
    button.textContent = text;
    button.style.background = "#2ecc71";
    button.disabled = true;
  },

  _detectEpisode(SITE_PARSER) {
    const se = SITE_PARSER.getSeasonEpisode();
    const title = SITE_PARSER.getTitle();
    if (!se || !title) return null;

    return {
      title,
      season: se.season,
      episode: se.episode,
      site: SITE_PARSER.siteName,
      key: `${SITE_PARSER.siteName}:${se.slug}`
    };
  },

  _createSyncBadge(data, alreadySynced) {
    const old = document.getElementById("mdl-sync-badge");
    if (old) old.remove();

    const badge = document.createElement("div");
    badge.id = "mdl-sync-badge";
    badge.style.cssText = `
      position: fixed; bottom: 16px; right: 16px; z-index: 2147483647;
      background: #1c1c1e; color: #fff; padding: 10px 14px;
      border-radius: 10px; font-family: sans-serif; font-size: 13px;
      box-shadow: 0 4px 12px rgba(0,0,0,.4); display: flex; align-items: center; gap: 10px;
    `;

    const label = document.createElement("span");
    label.textContent = `${data.title} — T${data.season}E${data.episode}`;
    badge.appendChild(label);

    const button = document.createElement("button");
    button.style.cssText = `
      background: #e91e63; color: #fff; border: none; padding: 6px 10px;
      border-radius: 6px; cursor: pointer; font-size: 12px;
    `;

    if (alreadySynced) {
      button.textContent = "Já sincronizado ✓";
      button.style.background = "#2ecc71";
      button.disabled = true;
    } else {
      button.textContent = "Marcar no MDL";
      button.onclick = () => {
        button.disabled = true;
        button.textContent = "Enviando...";
        chrome.runtime.sendMessage({ type: "SYNC_EPISODE", data }, (response) => {
          if (response?.ok) {
            button.textContent = "Sincronizado ✓";
            button.style.background = "#2ecc71";
            this._markAsSynced(data);
          } else {
            button.textContent = "Falhou ✗ (ver console)";
            button.style.background = "#e74c3c";
            button.disabled = false;
            console.warn("[MDL Sync] Falha ao sincronizar:", response?.error);
          }
        });
      };
    }

    badge.appendChild(button);
    document.body.appendChild(badge);
  }
};
